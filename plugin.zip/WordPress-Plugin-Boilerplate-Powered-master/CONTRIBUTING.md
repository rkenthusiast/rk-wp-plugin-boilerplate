# How to contribute

This project is based on the needs of the [Codeat web agency](https://codeat.co/) because our philosophy is to share what we create and use including our experience.  
We are open to any new idea that can improve what we do and this project of course, so don't hesitate to ask for help or suggest features.  

## The generator

This project is based in 2 parts the Plugin (wih libraries) and the [generator](https://github.com/WPBP/generator).  
When tere are issues about the plugin generated probably the fault is in the second part so is better to check what is happening to report in the right place.

